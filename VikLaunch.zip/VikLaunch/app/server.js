#!/usr/bin/env node
// VikLaunch — publish localhost apps, folders, files and links to <name>.vercel.app
// Runs on the laptop. Phones and iPads on the same Wi-Fi use it by scanning a QR code.
'use strict';
const http = require('http');
const fs = require('fs');
const os = require('os');
const net = require('net');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');
const { Readable } = require('stream');

const project = require('./lib/project');
const finder = require('./lib/finder');
const { crawl } = require('./lib/snapshot');
const { extractZip, isZip, safeJoin } = require('./lib/unzip');
const vercel = require('./lib/vercel');

const VERSION = '1.0.0';
const APP_DIR = __dirname;
const UI_DIR = path.join(APP_DIR, 'ui');
const DATA_DIR = process.env.VIKLAUNCH_DATA || path.join(APP_DIR, 'data');
const TMP = path.join(os.tmpdir(), 'viklaunch');
const BASE_PORT = parseInt(process.env.VIKLAUNCH_PORT || '4949', 10);
fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(TMP, { recursive: true });

// ---------- small persistent store ----------
function load(name, fallback) { try { return JSON.parse(fs.readFileSync(path.join(DATA_DIR, name), 'utf8')); } catch { return fallback; } }
function save(name, value) {
  const f = path.join(DATA_DIR, name);
  fs.writeFileSync(f + '.tmp', JSON.stringify(value, null, 2));
  fs.renameSync(f + '.tmp', f);
}
const config = load('config.json', {});
if (!config.key) {
  // 20 characters from an unambiguous alphabet ≈ 100 bits
  const abc = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  config.key = Array.from(crypto.randomBytes(20), (b) => abc[b % abc.length]).join('');
  save('config.json', config);
}
let history = load('history.json', []);

// ---------- in-memory work ----------
const sources = new Map(); // id → prepared thing to publish
const uploads = new Map(); // id → staged upload in progress
const jobs = new Map();    // id → publish job
const newId = () => crypto.randomBytes(8).toString('hex');
const tmpDir = (prefix) => { const d = path.join(TMP, `${prefix}-${Date.now().toString(36)}-${newId().slice(0, 6)}`); fs.mkdirSync(d, { recursive: true }); return d; };

function userError(message, extra) { const e = new Error(message); e.user = true; Object.assign(e, extra || {}); return e; }

// ---------- sources ----------
function sourceView(s, laptop) {
  return {
    id: s.id, kind: s.kind, label: s.label, badge: s.badge, notes: s.notes, files: s.files, bytes: s.bytes,
    suggestedName: s.suggestedName, where: laptop ? s.where : s.whereShort, how: s.how, canPublish: s.kind !== 'unknown',
  };
}

function registerSource({ dir, temp, tempRoot, origin, where, how, notes = [], nameHint }) {
  // Step into a lone wrapper folder (e.g. a folder that only contains "mygame/")
  for (let i = 0; i < 3; i++) {
    let entries = [];
    try { entries = fs.readdirSync(dir, { withFileTypes: true }).filter((e) => !['.DS_Store', '__MACOSX', 'Thumbs.db'].includes(e.name)); } catch {}
    if (entries.length === 1 && entries[0].isDirectory() && !project.SKIP_DIRS.has(entries[0].name)) dir = path.join(dir, entries[0].name);
    else break;
  }
  const stats = project.folderStats(dir);
  if (stats.files === 0) throw userError('That folder is empty.');
  const det = project.detect(dir);
  const allNotes = [...notes, ...det.notes];
  if (stats.secrets.length) allNotes.push(`Your ${stats.secrets.map((s) => path.basename(s)).filter((v, i, a) => a.indexOf(v) === i).join(', ')} file stays private and is not uploaded. If the app needs those values, add them in Vercel → Settings → Environment Variables.`);
  if (det.kind === 'unknown') allNotes.unshift("There's no index.html (home page) or app here, so the published site would be blank.");
  const s = {
    id: newId(), dir, temp: !!temp, tempRoot: tempRoot || (temp ? dir : null), origin, where: where || dir,
    whereShort: where && where.length < 60 ? where : path.basename(dir), how,
    kind: det.kind, label: det.label, badge: det.badge, notes: allNotes, files: stats.files, bytes: stats.bytes,
    suggestedName: (nameHint && project.slugify(nameHint)) || project.suggestName(dir, temp ? null : dir) || '',
    createdAt: Date.now(),
  };
  sources.set(s.id, s);
  return s;
}

function looksLikePath(s) {
  return /^[a-zA-Z]:[\\/]/.test(s) || /^\\\\/.test(s) || s.startsWith('/') || s.startsWith('~') || /^file:\/\//i.test(s);
}
function toPath(s) {
  let p = s.trim().replace(/^"|"$/g, '');
  if (/^file:\/\//i.test(p)) { try { p = require('url').fileURLToPath(p); } catch {} }
  if (p.startsWith('~')) p = path.join(os.homedir(), p.slice(1));
  return p;
}
const BIG_FOLDERS = ['downloads', 'desktop', 'documents', 'onedrive'];

async function sourceFromPath(input) {
  const p = toPath(input);
  if (!project.exists(p)) throw userError(`I can't find "${p}" on this computer. Check the spelling, or drag the folder in instead.`);
  if (project.isDir(p)) return registerSource({ dir: p, origin: { kind: 'folder', value: p }, where: p, how: 'Folder' });
  // A single file
  if (/\.zip$/i.test(p) || isZip(p)) {
    const stage = tmpDir('zip');
    extractZip(p, stage);
    const notes = project.normalizeStage(stage);
    return registerSource({ dir: stage, temp: true, origin: { kind: 'folder', value: p }, where: p, how: 'Zip file', notes, nameHint: path.basename(p).replace(/\.zip$/i, '') });
  }
  if (/\.html?$/i.test(p)) {
    const parent = path.dirname(p);
    const base = path.basename(parent).toLowerCase();
    let small = false;
    try { small = project.folderStats(parent).files <= 400; } catch {}
    const stage = tmpDir('file');
    if (small && !BIG_FOLDERS.includes(base) && path.resolve(parent) !== path.resolve(os.homedir())) {
      project.copyProject(parent, stage);
      if (path.basename(p).toLowerCase() !== 'index.html') fs.copyFileSync(p, path.join(stage, 'index.html'));
    } else {
      fs.copyFileSync(p, path.join(stage, 'index.html'));
    }
    return registerSource({ dir: stage, temp: true, origin: { kind: 'folder', value: p }, where: p, how: 'HTML file', nameHint: path.basename(p).replace(/\.html?$/i, '') });
  }
  throw userError("That's a single file I can't publish on its own. Give me its folder, an .html file or a .zip instead.");
}

async function download(url, dest, maxBytes = 600 * 1024 * 1024) {
  const r = await fetch(url, { redirect: 'follow' });
  if (!r.ok) throw userError(r.status === 404 ? "That link says 'not found' (404). If it's a private GitHub repo, download it as a .zip and drop it in instead." : `Couldn't download that link (error ${r.status}).`);
  const len = parseInt(r.headers.get('content-length') || '0', 10);
  if (len > maxBytes) throw userError('That download is too big.');
  await new Promise((resolve, reject) => {
    let got = 0;
    const out = fs.createWriteStream(dest);
    const body = Readable.fromWeb(r.body);
    body.on('data', (c) => { got += c.length; if (got > maxBytes) { body.destroy(); reject(userError('That download is too big.')); } });
    body.on('error', reject);
    out.on('error', reject);
    out.on('finish', resolve);
    body.pipe(out);
  });
  return r.headers.get('content-type') || '';
}

async function sourceFromWeb(input, log) {
  let s = input.trim();
  if (!/^https?:\/\//i.test(s)) s = 'https://' + s;
  let u;
  try { u = new URL(s); } catch { throw userError("That doesn't look like a link I can open."); }
  const gh = u.hostname.replace(/^www\./, '') === 'github.com' && u.pathname.match(/^\/([^/]+)\/([^/]+?)(?:\.git)?(?:\/(?:tree|blob)\/([^/]+)(?:\/(.*))?)?\/?$/);
  if (gh) {
    const [, owner, repo, ref, sub] = gh;
    const zipUrl = `https://github.com/${owner}/${repo}/archive/${ref ? encodeURIComponent(ref) : 'HEAD'}.zip`;
    log(`Downloading ${owner}/${repo} from GitHub…`);
    const root = tmpDir('gh');
    const z = path.join(root, 'repo.zip');
    await download(zipUrl, z);
    const stage = path.join(root, 'src');
    extractZip(z, stage);
    fs.rmSync(z, { force: true });
    const notes = project.normalizeStage(stage);
    let dir = stage;
    if (sub) {
      const subDir = safeJoin(stage, decodeURIComponent(sub));
      if (!subDir || !project.isDir(subDir)) throw userError(`Couldn't find the folder "${sub}" in that repo.`);
      dir = subDir;
    }
    return registerSource({ dir, temp: true, tempRoot: root, origin: { kind: 'link', value: input }, where: `github.com/${owner}/${repo}${sub ? '/' + sub : ''}`, how: 'GitHub', notes, nameHint: sub ? path.basename(sub) : repo });
  }
  if (/\.zip$/i.test(u.pathname)) {
    log('Downloading the .zip…');
    const root = tmpDir('dl');
    const z = path.join(root, 'download.zip');
    await download(u.href, z);
    const stage = path.join(root, 'src');
    extractZip(z, stage);
    const notes = project.normalizeStage(stage);
    return registerSource({ dir: stage, temp: true, tempRoot: root, origin: { kind: 'link', value: input }, where: u.href, how: 'Zip link', notes, nameHint: path.basename(u.pathname).replace(/\.zip$/i, '') });
  }
  return snapshotSource(u.href, input, log, 'Copied from the web');
}

async function snapshotSource(url, originalInput, log, how) {
  log('Copying every file the page uses…');
  const stage = tmpDir('snap');
  const r = await crawl(url, stage, { onLog: log });
  if (r.files === 0) throw userError("Couldn't copy anything from that page.");
  const notes = project.normalizeStage(stage);
  notes.push(`Copied ${r.files} files from the running page. Anything the page only loads later (e.g. a level you haven't reached) might be missing — open the live link and check.`);
  if (r.missing.length) notes.push(`${r.missing.length} file(s) the page asked for didn't load: ${r.missing.slice(0, 3).map((m) => new URL(m).pathname).join(', ')}${r.missing.length > 3 ? '…' : ''}`);
  let host = url;
  try { host = new URL(url).host; } catch {}
  return registerSource({ dir: stage, temp: true, origin: { kind: 'link', value: originalInput }, where: url, how, notes, nameHint: /localhost|127\.0\.0\.1/.test(host) ? '' : host.split('.')[0] });
}

async function resolveInput(input, log) {
  const s = String(input || '').trim();
  if (!s) throw userError('Paste a link or a folder first.');
  if (looksLikePath(s) && !/^\/\//.test(s)) return { source: await sourceFromPath(s) };
  const loc = finder.parseLocal(s);
  if (loc) {
    const r = await finder.findFolderForLink(s, log);
    if (r.reason === 'not_running') throw userError(`Nothing is running at ${loc.url.host} right now. Start your app first (or drop its folder here instead).`);
    if (r.dir) {
      const howText = { match: 'Found from the link', 'dev server': 'Found from the link', 'served folder': 'Found from the link', 'app file': 'Found from the link', 'working folder': 'Found from the link', search: 'Found by matching the page' }[r.how] || 'Found from the link';
      return { source: registerSource({ dir: r.dir, origin: { kind: 'link', value: s }, where: r.dir, how: howText }) };
    }
    return {
      needsChoice: true,
      canSnapshot: !r.isViteDev,
      message: r.isViteDev
        ? "Your app is running, but I couldn't work out which folder it's in. Paste the project's folder path or drop the folder here."
        : "Your app is running, but I couldn't work out which folder it's in. Paste the folder path or drop the folder here — or copy the running page as it is.",
      link: s,
    };
  }
  if (/^https?:\/\//i.test(s) || /^[\w-]+(\.[\w-]+)+(\/|$)/.test(s)) return { source: await sourceFromWeb(s, log) };
  throw userError("I didn't understand that. Paste a link (localhost:5173, github.com/…, a website) or a folder path like C:\\Users\\you\\games\\mygame.");
}

// ---------- name check ----------
async function nameStatus(slug) {
  if (history.some((h) => h.name === slug)) return 'yours';
  const ac = new AbortController();
  const t = setTimeout(() => ac.abort(), 5000);
  try {
    const r = await fetch(`https://${slug}.vercel.app/`, { redirect: 'manual', signal: ac.signal });
    const err = r.headers.get('x-vercel-error') || '';
    let body = '';
    if (r.status === 404) { try { body = (await r.text()).slice(0, 4000); } catch {} }
    if (err === 'DEPLOYMENT_NOT_FOUND' || /DEPLOYMENT_NOT_FOUND/.test(body)) return 'free';
    if (!r.headers.get('server') && !err) return 'unknown';
    return 'taken';
  } catch { return 'unknown'; } finally { clearTimeout(t); }
}

// ---------- publishing ----------
function addHistory(entry) {
  const prev = history.find((h) => h.name === entry.name);
  history = [Object.assign({}, prev, entry, { count: ((prev && prev.count) || 0) + 1 }), ...history.filter((h) => h.name !== entry.name)].slice(0, 200);
  save('history.json', history);
}

function startPublish(source, name) {
  const job = { id: newId(), name, phase: 'pack', lines: [], done: false, ok: false, url: null, error: null, reason: null, startedAt: Date.now() };
  jobs.set(job.id, job);
  const log = (l) => { job.lines.push(l); if (job.lines.length > 400) job.lines.splice(0, job.lines.length - 400); };
  (async () => {
    let stage = null;
    try {
      log('Getting the files ready…');
      // Always publish from a clean copy: no node_modules, .git, caches or .env secrets.
      stage = tmpDir('pub');
      project.copyProject(source.dir, stage);
      for (const n of project.normalizeStage(stage)) if (!source.temp) log(n);
      log('Checking your Vercel sign-in…');
      const who = await vercel.whoami(true);
      if (!who.signedIn) { job.reason = 'signin'; throw userError('Sign in to Vercel first (the yellow button at the top), then press Launch again.'); }
      job.phase = 'upload';
      log(`Uploading to Vercel as ${who.user}…`);
      const res = await vercel.deploy(stage, name, (line) => {
        log(line);
        if (job.phase === 'upload' && /(Building|Running build|Installing|Cloning|Build Completed|Deploying outputs|Queued|Inspect:|npm (install|run)|vite build|Collecting|Compiled)/i.test(line) && !/^Upload/i.test(line)) job.phase = 'build';
      });
      if (!res.ok) { job.reason = res.reason; throw userError(res.message || 'Publishing failed.'); }
      job.url = res.url;
      job.phase = 'live';
      job.ok = true;
      log(`Live at ${res.url}`);
      addHistory({ name, url: res.url, label: source.label, badge: source.badge, origin: source.origin, publishedAt: new Date().toISOString() });
      if (stage) fs.rm(stage, { recursive: true, force: true }, () => {});
    } catch (e) {
      job.error = e.user ? e.message : `Something went wrong: ${e.message}`;
      job.phase = 'error';
      log(job.error);
      if (stage) fs.rm(stage, { recursive: true, force: true }, () => {});
    } finally {
      job.done = true;
      job.finishedAt = Date.now();
    }
  })();
  return job;
}

// ---------- HTTP plumbing ----------
function isLoopback(req) {
  const a = req.socket.remoteAddress || '';
  return a === '127.0.0.1' || a === '::1' || a === '::ffff:127.0.0.1';
}
function hostAllowed(req) {
  const h = String(req.headers.host || '').toLowerCase().replace(/:\d+$/, '').replace(/^\[|\]$/g, '');
  const hn = os.hostname().toLowerCase();
  return h === 'localhost' || net.isIP(h) !== 0 || h === hn || h === hn + '.local' || h === hn + '.lan';
}
function send(res, status, body, headers = {}) {
  const isBuf = Buffer.isBuffer(body);
  const data = isBuf || typeof body === 'string' ? body : JSON.stringify(body);
  res.writeHead(status, Object.assign({
    'Content-Type': isBuf ? 'application/octet-stream' : typeof body === 'string' ? 'text/plain; charset=utf-8' : 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
  }, headers));
  res.end(data);
}
function readBody(req, max = 1e6) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => { size += c.length; if (size > max) { reject(userError('Request too large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch { reject(userError('Bad request')); } });
    req.on('error', reject);
  });
}

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.txt': 'text/plain; charset=utf-8' };
function serveStatic(req, res) {
  let p = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  if (p === '/') p = '/index.html';
  const f = safeJoin(UI_DIR, p);
  if (!f || !fs.existsSync(f) || fs.statSync(f).isDirectory()) return send(res, 404, 'Not found');
  res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream', 'Cache-Control': /\.(html|js)$/.test(p) ? 'no-cache' : 'max-age=86400' });
  fs.createReadStream(f).pipe(res);
}

function lanUrls(port) {
  const urls = [];
  for (const [ifname, list] of Object.entries(os.networkInterfaces())) {
    for (const a of list || []) {
      if (a.family !== 'IPv4' && a.family !== 4) continue;
      if (a.internal) continue;
      const ip = a.address;
      const priv = /^10\./.test(ip) || /^192\.168\./.test(ip) || /^172\.(1[6-9]|2\d|3[01])\./.test(ip) || /^100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\./.test(ip);
      if (!priv) continue;
      if (/vEthernet|VirtualBox|VMware|docker|br-|vboxnet|WSL|Hyper-V/i.test(ifname)) continue;
      urls.push({ ip, iface: ifname, url: `http://${ip}:${port}/#pair=${config.key}` });
    }
  }
  // Wi-Fi first, then 192.168.x, then the rest
  return urls.sort((a, b) => (/wi-?fi|wlan|en0/i.test(b.iface) - /wi-?fi|wlan|en0/i.test(a.iface)) || (/^192\.168/.test(b.ip) - /^192\.168/.test(a.ip)));
}

let PORT = BASE_PORT;
async function api(req, res, url, laptop) {
  const m = req.method;
  const p = url.pathname;

  if (p === '/api/state' && m === 'GET') {
    if (!vercel.cliInstalled() && !vercel.state.installing && !vercel.state.error) vercel.ensureCli().catch(() => {});
    let account = null;
    if (vercel.cliInstalled()) { try { account = await vercel.whoami(url.searchParams.has('refresh')); } catch { account = null; } }
    return send(res, 200, {
      version: VERSION, laptop,
      cli: { ready: vercel.cliInstalled(), installing: !!vercel.state.installing, error: vercel.state.error },
      account,
      login: { state: vercel.login.state, url: vercel.login.url, code: vercel.login.code, message: vercel.login.message },
      history,
    });
  }
  if (p === '/api/setup/retry' && m === 'POST') { vercel.state.error = null; vercel.ensureCli().catch(() => {}); return send(res, 200, { ok: true }); }
  if (p === '/api/login' && m === 'POST') { const l = await vercel.startLogin(); return send(res, 200, { state: l.state, url: l.url, code: l.code }); }
  if (p === '/api/login/cancel' && m === 'POST') { vercel.cancelLogin(); return send(res, 200, { ok: true }); }
  if (p === '/api/logout' && m === 'POST') { await vercel.logout(); return send(res, 200, { ok: true }); }

  if (p === '/api/resolve' && m === 'POST') {
    const body = await readBody(req);
    const lines = [];
    const r = await resolveInput(body.input, (l) => lines.push(l));
    if (r.source) return send(res, 200, { source: sourceView(r.source, laptop), log: lines });
    return send(res, 200, Object.assign({}, r, { log: lines }));
  }
  if (p === '/api/snapshot' && m === 'POST') {
    const body = await readBody(req);
    let link = String(body.link || '').trim();
    if (!/^https?:\/\//i.test(link)) link = 'http://' + link;
    const s = await snapshotSource(link.replace('://0.0.0.0', '://127.0.0.1'), body.link, () => {}, 'Copied from the running page');
    return send(res, 200, { source: sourceView(s, laptop) });
  }

  // uploads: start → PUT each file → finish
  if (p === '/api/upload/start' && m === 'POST') {
    const id = newId();
    uploads.set(id, { id, dir: tmpDir('up'), files: 0, bytes: 0, createdAt: Date.now() });
    return send(res, 200, { id });
  }
  let mm = p.match(/^\/api\/upload\/([a-f0-9]+)$/);
  if (mm && m === 'PUT') {
    const up = uploads.get(mm[1]);
    if (!up) throw userError('That upload expired. Please drop the files again.');
    const rel = String(url.searchParams.get('p') || '').replace(/\\/g, '/');
    const target = safeJoin(up.dir, rel);
    if (!rel || !target || target === up.dir) throw userError('Bad file name.');
    fs.mkdirSync(path.dirname(target), { recursive: true });
    await new Promise((resolve, reject) => {
      let got = 0;
      const out = fs.createWriteStream(target);
      req.on('data', (c) => { got += c.length; if (up.bytes + got > 1.5e9) { req.destroy(); reject(userError('Too much data.')); } });
      req.pipe(out);
      out.on('finish', () => { up.files++; up.bytes += got; resolve(); });
      out.on('error', reject);
      req.on('error', reject);
    });
    return send(res, 200, { ok: true });
  }
  mm = p.match(/^\/api\/upload\/([a-f0-9]+)\/finish$/);
  if (mm && m === 'POST') {
    const up = uploads.get(mm[1]);
    if (!up) throw userError('That upload expired. Please drop the files again.');
    const body = await readBody(req);
    uploads.delete(mm[1]);
    const notes = project.normalizeStage(up.dir);
    const label = String(body.label || '').slice(0, 120);
    const s = registerSource({ dir: up.dir, temp: true, origin: { kind: 'upload', value: label }, where: label || 'Your files', how: 'Uploaded', notes, nameHint: String(body.nameHint || '') });
    return send(res, 200, { source: sourceView(s, laptop) });
  }

  if (p === '/api/name' && m === 'GET') {
    const slug = project.slugify(url.searchParams.get('n') || '');
    if (!slug) return send(res, 200, { slug, status: 'empty' });
    return send(res, 200, { slug, status: await nameStatus(slug) });
  }

  if (p === '/api/publish' && m === 'POST') {
    const body = await readBody(req);
    const s = sources.get(body.sourceId);
    if (!s) throw userError('Those files expired. Please add them again.');
    const name = project.slugify(body.name);
    if (!name || name.length < 2) throw userError('Give it a name first (letters, numbers and dashes).');
    if (name.includes('---')) throw userError("Names can't contain three dashes in a row.");
    if (s.kind === 'unknown') throw userError("There's nothing to show in that folder (no index.html or app).");
    const job = startPublish(s, name);
    return send(res, 200, { jobId: job.id, name });
  }
  mm = p.match(/^\/api\/job\/([a-f0-9]+)$/);
  if (mm && m === 'GET') {
    const j = jobs.get(mm[1]);
    if (!j) return send(res, 404, { error: 'Unknown job' });
    const since = parseInt(url.searchParams.get('since') || '0', 10) || 0;
    return send(res, 200, { phase: j.phase, done: j.done, ok: j.ok, url: j.url, error: j.error, reason: j.reason, name: j.name, lines: j.lines.slice(since), total: j.lines.length });
  }

  if (p === '/api/history/remove' && m === 'POST') {
    const body = await readBody(req);
    history = history.filter((h) => h.name !== body.name);
    save('history.json', history);
    return send(res, 200, { ok: true, history });
  }

  if (p === '/api/pair' && m === 'GET') {
    if (!laptop) return send(res, 403, { error: 'Only on the laptop' });
    if (url.searchParams.has('reset')) {
      const abc = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
      config.key = Array.from(crypto.randomBytes(20), (b) => abc[b % abc.length]).join('');
      save('config.json', config);
    }
    return send(res, 200, { urls: lanUrls(PORT), port: PORT });
  }

  return send(res, 404, { error: 'Not found' });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  try {
    if (!hostAllowed(req)) return send(res, 403, 'Forbidden host');
    if (url.pathname === '/api/ping') return send(res, 200, { app: 'viklaunch', version: VERSION });
    if (url.pathname === '/manifest.webmanifest') {
      // Home-screen app: keep this device's pairing code in the start address
      const k = String(url.searchParams.get('k') || '').replace(/[^A-Z0-9]/g, '').slice(0, 64);
      return send(res, 200, JSON.stringify({
        name: 'VikLaunch', short_name: 'VikLaunch', description: 'Publish localhost apps, games and sites to a live link',
        start_url: k ? `/#pair=${k}` : '/', scope: '/', display: 'standalone', background_color: '#1f4fd6', theme_color: '#1f4fd6',
        icons: [
          { src: '/icon-192.png', sizes: '192x192', type: 'image/png' },
          { src: '/icon-512.png', sizes: '512x512', type: 'image/png' },
          { src: '/icon.svg', sizes: 'any', type: 'image/svg+xml' },
        ],
      }), { 'Content-Type': 'application/manifest+json' });
    }
    if (!url.pathname.startsWith('/api/')) return serveStatic(req, res);
    // API: block cross-site requests and unpaired devices
    if (req.headers['x-viklaunch'] !== '1') return send(res, 403, { error: 'Forbidden' });
    const laptop = isLoopback(req);
    if (!laptop && req.headers['x-viklaunch-key'] !== config.key) return send(res, 401, { error: 'not_paired', message: 'Scan the QR code on your laptop to connect this device.' });
    await api(req, res, url, laptop);
  } catch (e) {
    if (!res.headersSent) send(res, e.user ? 400 : 500, { error: e.user ? e.message : `Something went wrong: ${e.message}`, code: e.code || null });
    if (!e.user) console.error(e);
  }
});
server.requestTimeout = 0; // big uploads and long builds
server.headersTimeout = 60000;

// ---------- housekeeping ----------
setInterval(() => {
  const old = Date.now() - 3 * 3600 * 1000;
  for (const [id, s] of sources) if (s.createdAt < old) { if (s.temp && s.tempRoot) fs.rm(s.tempRoot, { recursive: true, force: true }, () => {}); sources.delete(id); }
  for (const [id, u] of uploads) if (u.createdAt < old) { fs.rm(u.dir, { recursive: true, force: true }, () => {}); uploads.delete(id); }
  for (const [id, j] of jobs) if (j.done && j.finishedAt < old) jobs.delete(id);
}, 10 * 60 * 1000).unref();

function openBrowser(u) {
  try {
    if (process.platform === 'win32') spawn('rundll32', ['url.dll,FileProtocolHandler', u], { detached: true, stdio: 'ignore' }).unref();
    else if (process.platform === 'darwin') spawn('open', [u], { detached: true, stdio: 'ignore' }).unref();
    else spawn('xdg-open', [u], { detached: true, stdio: 'ignore' }).on('error', () => {}).unref();
  } catch {}
}

async function alreadyRunning(port) {
  try {
    const r = await fetch(`http://127.0.0.1:${port}/api/ping`, { signal: AbortSignal.timeout(1500) });
    const j = await r.json();
    return j && j.app === 'viklaunch';
  } catch { return false; }
}

let bindHost = '::'; // all addresses (IPv6 + IPv4); falls back to IPv4-only if IPv6 is off
function listen(port, attempt = 0) {
  server.once('error', async (e) => {
    if ((e.code === 'EAFNOSUPPORT' || e.code === 'EADDRNOTAVAIL') && bindHost === '::') { bindHost = '0.0.0.0'; return listen(port, attempt); }
    if (e.code === 'EADDRINUSE') {
      if (await alreadyRunning(port)) {
        console.log(`VikLaunch is already running — opening http://localhost:${port}`);
        if (process.argv.includes('--open')) openBrowser(`http://localhost:${port}`);
        process.exit(0);
      }
      if (attempt < 10) return listen(port + 1, attempt + 1);
    }
    console.error('Could not start VikLaunch:', e.message);
    process.exit(1);
  });
  server.listen(port, bindHost);
}
let started = false;
server.on('listening', () => {
    if (started) return; // a retry (other port / IPv4 only) can fire this more than once
    started = true;
    const port = server.address().port;
    PORT = port;
    const local = `http://localhost:${port}`;
    console.log('');
    console.log('  VIKLAUNCH is running');
    console.log(`  On this laptop:  ${local}`);
    const lan = lanUrls(port)[0];
    if (lan) console.log(`  Phones & iPads:  open VikLaunch on the laptop and scan the QR code`);
    console.log('  Keep this window open while you use it. Close it to stop.');
    console.log('');
    if (process.argv.includes('--open')) openBrowser(local);
    if (!process.env.VIKLAUNCH_NO_SETUP) vercel.ensureCli().then(() => console.log('  Publishing tool ready.')).catch((err) => console.log('  ' + err.message.split('\n')[0]));
});
listen(BASE_PORT);
