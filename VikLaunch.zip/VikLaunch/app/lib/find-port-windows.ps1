# VikLaunch helper: which program is serving a localhost port, and which folder is it running in?
# Output: one line of JSON  { "port": 5173, "pids": [...], "chain": [ {pid,name,cmd,exe,cwd,ppid}, ... ] }
param([int]$Port)
$ErrorActionPreference = 'SilentlyContinue'

$src = @"
using System;
using System.Runtime.InteropServices;
using System.Text;
public static class VikProc {
  [StructLayout(LayoutKind.Sequential)]
  private struct PBI {
    public IntPtr ExitStatus; public IntPtr PebBaseAddress; public IntPtr AffinityMask;
    public IntPtr BasePriority; public IntPtr UniqueProcessId; public IntPtr InheritedFromUniqueProcessId;
  }
  [DllImport("ntdll.dll")] private static extern int NtQueryInformationProcess(IntPtr h, int cls, ref PBI pbi, int len, out int ret);
  [DllImport("kernel32.dll", SetLastError = true)] private static extern IntPtr OpenProcess(int access, bool inherit, int pid);
  [DllImport("kernel32.dll", SetLastError = true)] private static extern bool ReadProcessMemory(IntPtr h, IntPtr addr, byte[] buf, IntPtr size, out IntPtr read);
  [DllImport("kernel32.dll")] private static extern bool CloseHandle(IntPtr h);
  [DllImport("kernel32.dll")] private static extern bool IsWow64Process(IntPtr h, out bool wow);
  private static byte[] Read(IntPtr h, IntPtr addr, int n) {
    byte[] b = new byte[n]; IntPtr got;
    if (!ReadProcessMemory(h, addr, b, new IntPtr(n), out got)) return null;
    return b;
  }
  // Reads the current folder of another 64-bit process (PEB -> ProcessParameters -> CurrentDirectory).
  public static string Cwd(int pid) {
    if (IntPtr.Size != 8) return null;
    IntPtr h = OpenProcess(0x0410, false, pid);           // QUERY_INFORMATION | VM_READ
    if (h == IntPtr.Zero) h = OpenProcess(0x1010, false, pid); // QUERY_LIMITED_INFORMATION | VM_READ
    if (h == IntPtr.Zero) return null;
    try {
      bool wow;
      if (IsWow64Process(h, out wow) && wow) return null;
      PBI pbi = new PBI(); int ret;
      if (NtQueryInformationProcess(h, 0, ref pbi, Marshal.SizeOf(typeof(PBI)), out ret) != 0) return null;
      byte[] p = Read(h, IntPtr.Add(pbi.PebBaseAddress, 0x20), 8);
      if (p == null) return null;
      IntPtr pp = new IntPtr(BitConverter.ToInt64(p, 0));
      byte[] us = Read(h, IntPtr.Add(pp, 0x38), 16);
      if (us == null) return null;
      int len = BitConverter.ToUInt16(us, 0);
      IntPtr buf = new IntPtr(BitConverter.ToInt64(us, 8));
      if (len <= 0 || len > 8192) return null;
      byte[] s = Read(h, buf, len);
      if (s == null) return null;
      return Encoding.Unicode.GetString(s);
    } catch { return null; }
    finally { CloseHandle(h); }
  }
}
"@
try { Add-Type -TypeDefinition $src -Language CSharp } catch {}

function Get-Cwd([int]$id) {
  try { return [VikProc]::Cwd($id) } catch { return $null }
}

# 1) Which process is listening on the port?
$pids = @()
try {
  $pids = @(Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction Stop |
    Select-Object -ExpandProperty OwningProcess -Unique)
} catch {}
if ($pids.Count -eq 0) {
  foreach ($line in (netstat -ano)) {
    if ($line -match '^\s*TCP\s+\S*[:\]](\d+)\s+\S+\s+LISTENING\s+(\d+)\s*$') {
      if ([int]$Matches[1] -eq $Port) { $pids += [int]$Matches[2] }
    }
  }
  $pids = @($pids | Select-Object -Unique)
}

# 2) Walk up from that process to its parents (npm -> shell -> terminal) collecting folders.
$chain = @()
$first = $pids | Where-Object { $_ -gt 4 } | Select-Object -First 1
$cur = [int]$first
for ($i = 0; $i -lt 6 -and $cur -gt 4; $i++) {
  $p = Get-CimInstance Win32_Process -Filter "ProcessId=$cur"
  if (-not $p) { break }
  $chain += [pscustomobject]@{
    pid  = $cur
    ppid = [int]$p.ParentProcessId
    name = $p.Name
    cmd  = $p.CommandLine
    exe  = $p.ExecutablePath
    cwd  = (Get-Cwd $cur)
  }
  if ($p.Name -match '^(explorer|services|wininit|svchost|Code|cursor|WindowsTerminal)\.exe$') { break }
  $cur = [int]$p.ParentProcessId
}

$result = [pscustomobject]@{ port = $Port; pids = @($pids); chain = @($chain) }
$result | ConvertTo-Json -Depth 5 -Compress
