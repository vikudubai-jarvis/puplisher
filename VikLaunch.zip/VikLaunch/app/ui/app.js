/* VikLaunch front end — works on laptop, iPad, iPhone and Android */
(function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const store = {
    get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* private mode */ } },
  };
  const isTouch = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);

  // ---------- pairing (phones / iPads) ----------
  let key = null;
  const hm = location.hash.match(/pair=([A-Z0-9]{8,64})/);
  if (hm) { key = hm[1]; store.set('viklaunch-key', key); } else { key = store.get('viklaunch-key'); }
  if (key) $('manifest').href = 'manifest.webmanifest?k=' + encodeURIComponent(key);

  // ---------- state ----------
  let S = { laptop: false, account: null, cli: null, history: [], login: {} };
  let source = null;
  let nameTouched = false;
  let busy = false;
  let pendingLaunch = false;
  let pairLoaded = false;
  let stateTimer = null;

  // ---------- helpers ----------
  async function api(path, opts) {
    opts = opts || {};
    const headers = { 'x-viklaunch': '1' };
    if (key) headers['x-viklaunch-key'] = key;
    let body = opts.body;
    if (opts.json !== undefined) { headers['content-type'] = 'application/json'; body = JSON.stringify(opts.json); }
    let r;
    try {
      r = await fetch(path, { method: opts.method || (opts.json !== undefined ? 'POST' : 'GET'), headers, body });
    } catch (e) {
      throw new Error(S.laptop ? 'VikLaunch stopped. Double-click “Start VikLaunch” again.' : "Can't reach your laptop. Is it on, with VikLaunch open, on the same Wi-Fi?");
    }
    let j = null;
    try { j = await r.json(); } catch (e) { /* not json */ }
    if (r.status === 401) { showPairNeeded(); throw new Error((j && j.message) || 'This device is not connected yet.'); }
    if (!r.ok) { const err = new Error((j && j.error) || 'Error ' + r.status); err.data = j; throw err; }
    return j;
  }

  let toastTimer;
  function toast(msg) {
    let t = document.querySelector('.toast');
    if (!t) { t = document.createElement('div'); t.className = 'toast'; document.body.appendChild(t); }
    t.textContent = msg;
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { t.remove(); }, 3200);
  }

  function slugify(s, final) {
    let out = String(s || '').normalize('NFKD').replace(/[̀-ͯ]/g, '').toLowerCase()
      .replace(/[^a-z0-9-]+/g, '-').replace(/-+/g, '-').replace(/^-/, '').slice(0, 50);
    if (final) out = out.replace(/-$/, '');
    return out;
  }
  function size(b) {
    if (b < 1024) return b + ' B';
    if (b < 1024 * 1024) return (b / 1024).toFixed(0) + ' KB';
    if (b < 1024 * 1024 * 1024) return (b / 1024 / 1024).toFixed(1) + ' MB';
    return (b / 1024 / 1024 / 1024).toFixed(2) + ' GB';
  }
  function ago(iso) {
    const s = (Date.now() - new Date(iso).getTime()) / 1000;
    if (s < 60) return 'just now';
    if (s < 3600) return Math.floor(s / 60) + ' min ago';
    if (s < 86400) return Math.floor(s / 3600) + ' h ago';
    if (s < 86400 * 30) return Math.floor(s / 86400) + ' days ago';
    return new Date(iso).toLocaleDateString();
  }
  function qrSvg(text, cell) {
    try {
      const q = qrcode(0, 'M');
      q.addData(text);
      q.make();
      return q.createSvgTag({ cellSize: cell || 4, margin: 2, scalable: true });
    } catch (e) { return ''; }
  }
  const host = (u) => String(u || '').replace(/^https?:\/\//, '').replace(/\/$/, '');

  // ---------- state & header ----------
  async function refreshState(force) {
    let st;
    try { st = await api('/api/state' + (force ? '?refresh=1' : '')); } catch (e) { if (!S.laptop && !key) return; toast(e.message); return; }
    S = st;
    $('pairNeeded').classList.add('hidden');
    $('main').classList.remove('hidden');
    renderAccount();
    renderSetup();
    renderSites();
    renderFooter();
    if (S.laptop) {
      $('phoneCard').classList.remove('hidden');
      if (!pairLoaded) loadPair();
    }
    $('input').placeholder = S.laptop ? 'localhost:5173, a folder path, or a link' : 'A link: github.com/…, a website, or localhost:… on the laptop';
    $('dropHint').textContent = isTouch ? 'Tap to choose files or a .zip from this device.' : 'Games, websites and apps — whatever you made.';
    $('pickFolder').classList.toggle('hidden', isTouch);
    clearTimeout(stateTimer);
    if (!S.cli.ready) stateTimer = setTimeout(refreshState, 3000);
    updateLaunch();
    if (pendingLaunch && S.account && S.account.signedIn) { pendingLaunch = false; launch(); }
  }

  function renderAccount() {
    const el = $('account');
    if (!S.cli.ready) { el.innerHTML = ''; return; }
    if (S.account && S.account.signedIn) {
      el.innerHTML = `<span class="chip" title="Signed in to Vercel"><span class="dot"></span>${esc(S.account.user)}</span>`;
    } else {
      el.innerHTML = '<button class="btn yellow" id="signInBtn">Sign in to Vercel</button>';
      $('signInBtn').onclick = startLogin;
    }
  }

  function renderSetup() {
    const b = $('setup');
    if (S.cli.ready) { b.classList.add('hidden'); return; }
    b.classList.remove('hidden');
    if (S.cli.error) {
      b.innerHTML = `<div>${esc(S.cli.error.split('\n')[0])}</div><div style="margin-top:10px"><button class="btn small" id="retrySetup">Try again</button></div>`;
      $('retrySetup').onclick = async () => { await api('/api/setup/retry', { json: {} }); b.innerHTML = '<div>Getting ready — one-time setup, about a minute…</div><div class="bar"><i></i></div>'; setTimeout(refreshState, 1500); };
    } else if (!b.querySelector('.bar')) {
      b.innerHTML = '<div>Getting ready — one-time setup, about a minute…</div><div class="bar"><i></i></div>';
    }
  }

  function renderFooter() {
    const f = $('footer');
    const who = S.account && S.account.signedIn ? `Signed in to Vercel as <b>${esc(S.account.user)}</b> · <button class="btn link" id="signOut">Sign out</button> · ` : '';
    f.innerHTML = `${who}VikLaunch ${esc(S.version || '')}`;
    const so = $('signOut');
    if (so) so.onclick = async () => {
      if (!confirm('Sign out of Vercel on this laptop?')) return;
      await api('/api/logout', { json: {} });
      refreshState(true);
    };
  }

  function showPairNeeded() {
    $('pairNeeded').classList.remove('hidden');
    $('main').classList.add('hidden');
  }

  // ---------- sign in ----------
  let loginTimer = null;
  async function startLogin() {
    const m = $('loginModal');
    m.classList.remove('hidden');
    $('loginBody').innerHTML = '<p><span class="spin"></span> Opening Vercel’s sign-in page…</p>';
    $('loginOpen').classList.add('hidden');
    try {
      await api('/api/login', { json: {} });
    } catch (e) {
      $('loginBody').innerHTML = `<div class="error">${esc(e.message)}</div>`;
      return;
    }
    pollLogin();
  }
  async function pollLogin() {
    clearTimeout(loginTimer);
    let st;
    try { st = await api('/api/state?refresh=1'); } catch (e) { loginTimer = setTimeout(pollLogin, 2500); return; }
    S = st;
    const l = st.login || {};
    if (st.account && st.account.signedIn) {
      $('loginModal').classList.add('hidden');
      toast('Signed in as ' + st.account.user);
      refreshState();
      return;
    }
    if (l.state === 'error') {
      $('loginBody').innerHTML = `<div class="error">Sign-in didn't finish: ${esc(l.message || '')}</div><p><button class="btn yellow" id="loginRetry">Try again</button></p>`;
      $('loginRetry').onclick = startLogin;
      return;
    }
    const where = S.laptop ? 'A Vercel page should have opened in your browser.' : 'Tap the button below to sign in on this device.';
    $('loginBody').innerHTML = `
      <p>${where} Sign in there — no account yet? Create a free one (<b>Continue with GitHub</b> is quickest).</p>
      ${l.code ? `<p style="margin-bottom:0">Check the page shows this code:</p><div class="code">${esc(l.code)}</div>` : ''}
      <p class="sub" style="margin:8px 0 0"><span class="spin"></span> This box closes by itself when you’re done.</p>`;
    if (l.url) { $('loginOpen').href = l.url; $('loginOpen').classList.remove('hidden'); }
    loginTimer = setTimeout(pollLogin, l.url ? 2500 : 800);
  }
  $('loginCancel').onclick = async () => {
    clearTimeout(loginTimer);
    pendingLaunch = false;
    $('loginModal').classList.add('hidden');
    try { await api('/api/login/cancel', { json: {} }); } catch (e) { /* ignore */ }
  };

  // ---------- step 1: what ----------
  function setBusyResolve(text) {
    $('resolveOut').innerHTML = `<div class="notice"><span class="spin"></span> ${esc(text)}</div>`;
  }
  function showResolveError(msg) {
    $('resolveOut').innerHTML = `<div class="found bad"><div class="label">Hmm.</div><div style="margin-top:6px">${esc(msg)}</div></div>`;
  }

  async function resolveInput() {
    const v = $('input').value.trim();
    if (!v) { $('input').focus(); return; }
    source = null; updateLaunch();
    const local = /^(https?:\/\/)?(localhost|127\.|0\.0\.0\.0|\[::1\])/i.test(v);
    const isPath = /^[a-zA-Z]:[\\/]|^\\\\|^\/|^~|^"/.test(v);
    setBusyResolve(local ? 'Finding the folder behind that link…' : isPath ? 'Checking that folder…' : 'Fetching that link…');
    $('findBtn').disabled = true;
    try {
      const r = await api('/api/resolve', { json: { input: v } });
      if (r.source) setSource(r.source);
      else if (r.needsChoice) showChoice(r);
    } catch (e) {
      showResolveError(e.message);
    } finally {
      $('findBtn').disabled = false;
    }
  }

  function showChoice(r) {
    $('resolveOut').innerHTML = `
      <div class="notice">
        <div>${esc(r.message)}</div>
        <div class="btns">
          ${r.canSnapshot ? '<button class="btn small yellow" id="snapBtn">Copy the running page</button>' : ''}
          ${!isTouch ? '<button class="btn small" id="choiceFolder">Choose the folder</button>' : ''}
        </div>
      </div>`;
    const sb = $('snapBtn');
    if (sb) sb.onclick = async () => {
      setBusyResolve('Copying the running page and everything it loads…');
      try { const x = await api('/api/snapshot', { json: { link: r.link } }); setSource(x.source); } catch (e) { showResolveError(e.message); }
    };
    const cf = $('choiceFolder');
    if (cf) cf.onclick = () => $('folderInput').click();
  }

  function setSource(s) {
    source = s;
    const meta = [s.where, `${s.files} file${s.files === 1 ? '' : 's'}`, size(s.bytes), s.how].filter(Boolean).map(esc).join(' · ');
    $('resolveOut').innerHTML = `
      <div class="found ${s.canPublish ? '' : 'bad'}">
        <div class="top"><span class="badge">${esc(s.badge)}</span><span class="label">${esc(s.label)}</span><button class="btn small change" id="changeSrc">Change</button></div>
        <div class="where">${meta}</div>
        ${s.notes && s.notes.length ? `<ul>${s.notes.map((n) => `<li>${esc(n)}</li>`).join('')}</ul>` : ''}
      </div>`;
    $('changeSrc').onclick = () => { source = null; $('resolveOut').innerHTML = ''; $('input').focus(); updateLaunch(); };
    if ((!nameTouched || !$('name').value) && s.suggestedName) {
      $('name').value = s.suggestedName;
      checkName();
    }
    updateLaunch();
    if (!$('name').value) $('name').focus();
  }

  $('findBtn').onclick = resolveInput;
  $('input').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); resolveInput(); } });
  $('input').addEventListener('paste', () => setTimeout(() => { if ($('input').value.trim()) resolveInput(); }, 30));

  // ---------- uploads ----------
  const SKIP = new Set(['node_modules', '.git', '.vercel', '.next', '.nuxt', '.svelte-kit', '__pycache__', '.venv', 'venv', '.cache', '.DS_Store', 'Thumbs.db', '__MACOSX', 'desktop.ini', '.idea', '.vscode']);
  const keep = (p) => !p.split('/').some((seg) => SKIP.has(seg)) && !/(^|\/)\.env(\.[^/]*)?$/.test(p) && !/(^|\/)\._/.test(p);

  async function filesFromDrop(dt) {
    const items = Array.from(dt.items || []).filter((i) => i.kind === 'file');
    const entries = items.map((i) => (i.webkitGetAsEntry ? i.webkitGetAsEntry() : null));
    const plain = Array.from(dt.files || []);
    if (!entries.length || !entries.every(Boolean)) return plain.map((f) => ({ file: f, path: f.name }));
    const out = [];
    const walk = async (entry, prefix) => {
      if (entry.isFile) {
        const f = await new Promise((res, rej) => entry.file(res, rej));
        out.push({ file: f, path: prefix + f.name });
      } else if (entry.isDirectory) {
        if (SKIP.has(entry.name)) return;
        const reader = entry.createReader();
        let batch;
        do {
          batch = await new Promise((res, rej) => reader.readEntries(res, rej));
          for (const e of batch) await walk(e, prefix + entry.name + '/');
        } while (batch.length);
      }
    };
    for (const e of entries) await walk(e, '');
    return out;
  }

  function putFile(id, item, onProgress) {
    return new Promise((resolve, reject) => {
      const x = new XMLHttpRequest();
      x.open('PUT', '/api/upload/' + id + '?p=' + encodeURIComponent(item.path));
      x.setRequestHeader('x-viklaunch', '1');
      if (key) x.setRequestHeader('x-viklaunch-key', key);
      x.upload.onprogress = (e) => onProgress(e.loaded);
      x.onload = () => {
        if (x.status < 300) { onProgress(item.file.size); resolve(); return; }
        let m = 'Upload failed';
        try { m = JSON.parse(x.responseText).error || m; } catch (e) { /* ignore */ }
        if (x.status === 401) showPairNeeded();
        reject(new Error(m));
      };
      x.onerror = () => reject(new Error("Upload failed — is the laptop still on and on the same Wi-Fi?"));
      x.send(item.file);
    });
  }

  async function uploadFiles(list) {
    list = list.filter((f) => keep(f.path));
    if (!list.length) { toast('Nothing to upload there.'); return; }
    // label + name hint
    const tops = new Set(list.map((f) => f.path.split('/')[0]));
    const oneFolder = tops.size === 1 && list[0].path.includes('/');
    const first = list[0].path.split('/')[0];
    const nameHint = oneFolder ? first : list.length === 1 ? first.replace(/\.[^.]+$/, '') : '';
    const label = oneFolder ? first : list.length === 1 ? first : `${list.length} files`;

    source = null; updateLaunch();
    $('resolveOut').innerHTML = '';
    const total = list.reduce((a, f) => a + f.file.size, 0) || 1;
    const loaded = new Array(list.length).fill(0);
    const bar = $('upBar'), txt = $('upText');
    bar.classList.remove('hidden'); txt.classList.remove('hidden');
    let done = 0;
    const paint = () => {
      const sum = loaded.reduce((a, b) => a + b, 0);
      bar.firstElementChild.style.width = Math.min(100, (sum / total) * 100).toFixed(1) + '%';
      txt.textContent = `Sending ${done} / ${list.length} file${list.length === 1 ? '' : 's'} · ${size(sum)} of ${size(total)}`;
    };
    paint();
    try {
      const { id } = await api('/api/upload/start', { json: {} });
      let next = 0;
      const worker = async () => {
        while (next < list.length) {
          const i = next++;
          await putFile(id, list[i], (n) => { loaded[i] = n; paint(); });
          done++; paint();
        }
      };
      await Promise.all([worker(), worker(), worker(), worker()]);
      txt.textContent = 'Checking what you sent…';
      const r = await api('/api/upload/' + id + '/finish', { json: { label, nameHint } });
      setSource(r.source);
    } catch (e) {
      showResolveError(e.message);
    } finally {
      bar.classList.add('hidden'); txt.classList.add('hidden');
      bar.firstElementChild.style.width = '0';
    }
  }

  const drop = $('drop');
  ['dragenter', 'dragover'].forEach((ev) => document.addEventListener(ev, (e) => { if (e.dataTransfer && Array.from(e.dataTransfer.types || []).includes('Files')) { e.preventDefault(); drop.classList.add('over'); } }));
  ['dragleave', 'dragend'].forEach((ev) => document.addEventListener(ev, (e) => { if (!e.relatedTarget) drop.classList.remove('over'); }));
  document.addEventListener('drop', async (e) => {
    if (!e.dataTransfer || !e.dataTransfer.files || !e.dataTransfer.files.length) return;
    e.preventDefault();
    drop.classList.remove('over');
    const list = await filesFromDrop(e.dataTransfer);
    uploadFiles(list);
  });
  $('pickFiles').onclick = (e) => { e.stopPropagation(); $('fileInput').click(); };
  $('pickFolder').onclick = (e) => { e.stopPropagation(); $('folderInput').click(); };
  drop.addEventListener('click', (e) => { if (e.target === drop || e.target.classList.contains('big') || e.target.classList.contains('small')) $('fileInput').click(); });
  $('fileInput').onchange = (e) => { const fl = Array.from(e.target.files || []); e.target.value = ''; uploadFiles(fl.map((f) => ({ file: f, path: f.name }))); };
  $('folderInput').onchange = (e) => { const fl = Array.from(e.target.files || []); e.target.value = ''; uploadFiles(fl.map((f) => ({ file: f, path: f.webkitRelativePath || f.name }))); };

  // ---------- step 2: name ----------
  let nameTimer = null;
  let nameSeq = 0;
  $('name').addEventListener('input', () => {
    nameTouched = true;
    const el = $('name');
    const clean = slugify(el.value);
    if (clean !== el.value) el.value = clean;
    clearTimeout(nameTimer);
    nameTimer = setTimeout(checkName, 450);
    updateLaunch();
  });
  $('name').addEventListener('blur', () => { $('name').value = slugify($('name').value, true); updateLaunch(); });
  $('name').addEventListener('keydown', (e) => { if (e.key === 'Enter' && !$('launch').disabled) launch(); });

  async function checkName() {
    const n = slugify($('name').value, true);
    const el = $('nameStatus');
    if (!n) { el.innerHTML = ''; return; }
    if (n.length < 2) { el.innerHTML = '<span class="pill unknown">TOO SHORT</span> At least 2 letters.'; return; }
    const seq = ++nameSeq;
    el.innerHTML = '<span class="spin"></span> Checking…';
    let r;
    try { r = await api('/api/name?n=' + encodeURIComponent(n)); } catch (e) { el.innerHTML = ''; return; }
    if (seq !== nameSeq) return;
    const msg = {
      free: ['free', 'FREE', `<b>${esc(n)}.vercel.app</b> is yours if you launch now.`],
      yours: ['yours', 'YOURS', 'You launched this before — launching again updates it.'],
      taken: ['taken', 'TAKEN', 'Someone already uses this name. Unless it’s yours, Vercel will give you a slightly different address — or pick another name.'],
      unknown: ['unknown', '?', 'Couldn’t check right now — you can still launch.'],
    }[r.status];
    el.innerHTML = msg ? `<span class="pill ${msg[0]}">${msg[1]}</span> <span>${msg[2]}</span>` : '';
  }

  function updateLaunch() {
    const n = slugify($('name').value, true);
    const ready = !!(source && source.canPublish && n.length >= 2 && !busy && S.cli && S.cli.ready);
    $('launch').disabled = !ready;
    $('launch').textContent = busy ? 'LAUNCHING…' : 'LAUNCH!';
  }

  // ---------- launch ----------
  const ORDER = ['pack', 'upload', 'build', 'live'];
  const PHASE_MSG = {
    pack: 'Packing up your files…',
    upload: 'Uploading to Vercel…',
    build: 'Building it in the cloud — apps can take a minute or two…',
    live: 'Done!',
  };
  function paintSteps(phase, failed) {
    const idx = ORDER.indexOf(phase);
    document.querySelectorAll('.step').forEach((el) => {
      const i = ORDER.indexOf(el.dataset.step);
      el.className = 'step' + (failed && i === Math.max(0, idx) ? ' fail' : i < idx || phase === 'live' ? ' done' : i === idx ? ' on' : '');
    });
  }

  async function launch() {
    if (busy || !source) return;
    if (!S.account || !S.account.signedIn) { pendingLaunch = true; startLogin(); return; }
    const name = slugify($('name').value, true);
    busy = true; updateLaunch();
    $('liveCard').classList.add('hidden');
    const pc = $('progressCard');
    pc.classList.remove('hidden');
    $('progressTitle').textContent = `Launching ${name}…`;
    $('progressErr').classList.add('hidden');
    $('log').textContent = '';
    $('logBox').open = false;
    paintSteps('pack');
    $('progressMsg').textContent = PHASE_MSG.pack;
    pc.scrollIntoView({ behavior: 'smooth', block: 'center' });
    try {
      const r = await api('/api/publish', { json: { sourceId: source.id, name } });
      pollJob(r.jobId, 0, Date.now(), 'pack');
    } catch (e) {
      failJob(e.message, null, 'pack');
    }
  }

  function failJob(msg, reason, lastPhase) {
    busy = false; updateLaunch();
    paintSteps(lastPhase || 'pack', true);
    $('progressTitle').textContent = 'Not launched';
    $('progressMsg').textContent = '';
    const box = $('progressErr');
    box.classList.remove('hidden');
    box.innerHTML = esc(msg) + (reason === 'signin' ? ' <div style="margin-top:10px"><button class="btn yellow small" id="errSignIn">Sign in to Vercel</button></div>' : '');
    const b = $('errSignIn');
    if (b) b.onclick = () => { pendingLaunch = true; startLogin(); };
    $('logBox').open = !reason;
  }

  async function pollJob(id, since, t0, lastPhase) {
    let j;
    try { j = await api('/api/job/' + id + '?since=' + since); }
    catch (e) { setTimeout(() => pollJob(id, since, t0, lastPhase), 2000); return; }
    if (j.lines && j.lines.length) {
      const log = $('log');
      const atBottom = log.scrollTop + log.clientHeight >= log.scrollHeight - 30;
      log.textContent += j.lines.join('\n') + '\n';
      if (atBottom) log.scrollTop = log.scrollHeight;
    }
    if (j.phase !== 'error') { paintSteps(j.phase); $('progressMsg').textContent = PHASE_MSG[j.phase] || ''; lastPhase = j.phase; }
    if (!j.done) { setTimeout(() => pollJob(id, j.total, t0, lastPhase), 900); return; }
    if (!j.ok) { failJob(j.error || 'Publishing failed.', j.reason, lastPhase); return; }
    busy = false; updateLaunch();
    paintSteps('live');
    const secs = Math.round((Date.now() - t0) / 1000);
    $('progressTitle').textContent = `Launched in ${secs}s`;
    $('progressMsg').textContent = '';
    showLive(j.url);
    refreshState();
  }

  function showLive(url) {
    const card = $('liveCard');
    card.classList.remove('hidden');
    $('liveUrl').textContent = host(url);
    $('liveUrl').href = url;
    $('openLive').href = url;
    $('liveQr').innerHTML = qrSvg(url, 4);
    $('shareLive').classList.toggle('hidden', !navigator.share);
    $('copyLive').onclick = async () => {
      try { await navigator.clipboard.writeText(url); toast('Link copied'); }
      catch (e) {
        const r = document.createRange(); r.selectNodeContents($('liveUrl'));
        const sel = getSelection(); sel.removeAllRanges(); sel.addRange(r);
        toast('Press Ctrl+C / ⌘C to copy');
      }
    };
    $('shareLive').onclick = () => navigator.share({ title: host(url), url }).catch(() => {});
    card.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
  $('launch').onclick = launch;
  $('again').onclick = () => {
    source = null; nameTouched = false;
    $('name').value = ''; $('nameStatus').innerHTML = ''; $('input').value = ''; $('resolveOut').innerHTML = '';
    $('liveCard').classList.add('hidden'); $('progressCard').classList.add('hidden');
    updateLaunch();
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setTimeout(() => $('input').focus(), 300);
  };

  // ---------- your sites ----------
  function renderSites() {
    const ul = $('sites');
    if (!S.history || !S.history.length) { ul.innerHTML = '<li class="empty">Nothing launched yet. Your sites will show up here.</li>'; return; }
    ul.innerHTML = S.history.map((h, i) => {
      const from = h.origin && h.origin.value ? ` · from ${esc(h.origin.kind === 'upload' ? 'uploaded files' : h.origin.value)}` : '';
      return `<li class="site">
        <div class="info">
          <div class="n">${esc(h.name)}</div>
          <a class="u" href="${esc(h.url)}" target="_blank" rel="noopener">${esc(host(h.url))}</a>
          <div class="meta">${esc(h.label || '')} · ${esc(ago(h.publishedAt))}${from}</div>
        </div>
        <div class="acts">
          <a class="btn small" href="${esc(h.url)}" target="_blank" rel="noopener">Open</a>
          <button class="btn small yellow" data-i="${i}">Update</button>
        </div>
      </li>`;
    }).join('');
    ul.querySelectorAll('button[data-i]').forEach((b) => { b.onclick = () => updateSite(S.history[+b.dataset.i]); });
  }

  function updateSite(h) {
    $('liveCard').classList.add('hidden');
    $('progressCard').classList.add('hidden');
    $('name').value = h.name; nameTouched = true; checkName();
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (h.origin && (h.origin.kind === 'folder' || h.origin.kind === 'link') && h.origin.value) {
      $('input').value = h.origin.value;
      resolveInput();
    } else {
      source = null; $('resolveOut').innerHTML = ''; updateLaunch();
      toast(`Drop the new files for ${h.name}`);
    }
  }

  // ---------- phone pairing (laptop only) ----------
  async function loadPair(reset) {
    try {
      const r = await api('/api/pair' + (reset ? '?reset=1' : ''));
      pairLoaded = true;
      if (!r.urls.length) {
        $('pairQr').classList.add('hidden');
        $('pairUrl').className = 'error';
        $('pairUrl').textContent = 'This laptop isn’t on a Wi-Fi network right now. Connect to Wi-Fi, then reopen VikLaunch.';
        return;
      }
      $('pairQr').classList.remove('hidden');
      $('pairUrl').className = 'mono';
      $('pairQr').innerHTML = qrSvg(r.urls[0].url, 4);
      $('pairUrl').textContent = r.urls[0].url.replace(/#.*/, '');
    } catch (e) { /* not fatal */ }
  }
  $('pairReset').onclick = () => { if (confirm('Make a new code? Phones and iPads you connected before will need to scan again.')) loadPair(true); };

  // ---------- go ----------
  refreshState();
  setInterval(() => { if (!busy && document.visibilityState === 'visible') refreshState(); }, 60000);
})();
