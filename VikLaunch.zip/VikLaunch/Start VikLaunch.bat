@echo off
setlocal
title VikLaunch
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 goto :nonode

node app\server.js --open
if errorlevel 1 (
  echo.
  echo  VikLaunch stopped with an error - see the message above.
  pause
)
exit /b

:nonode
echo.
echo  VikLaunch needs Node.js - a free program from nodejs.org.
echo  Installing it now...
echo.
where winget >nul 2>nul
if errorlevel 1 goto :manual
winget install -e --id OpenJS.NodeJS.LTS --accept-source-agreements --accept-package-agreements
if errorlevel 1 goto :manual
echo.
echo  Node.js is installed. Double-click "Start VikLaunch" again to open VikLaunch.
echo.
pause
exit /b

:manual
echo  Opening the Node.js download page. Install the "LTS" version,
echo  then double-click "Start VikLaunch" again.
start "" "https://nodejs.org/en/download"
echo.
pause
exit /b
