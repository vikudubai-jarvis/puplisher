#!/bin/sh
# VikLaunch for macOS / Linux. On a Mac you can double-click this file.
cd "$(dirname "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
  echo "VikLaunch needs Node.js (free). Get the LTS version from https://nodejs.org and run this again."
  exit 1
fi
exec node app/server.js --open
